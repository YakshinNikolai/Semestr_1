﻿using System;

class Program
{
    static void Main()
    {
        int[] arr = { 10, 20, 21, 29, 30, 31, 33, 39, 40, 42, 47, 49, 50 };
        foreach (int num in arr)
        {
            if (num > 20 && num < 50)
            {
                Console.Write(num + " ");
            }
        }
    }
}