﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите положительное целое число A: ");
        int A = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите положительное целое число B: ");
        int B = Convert.ToInt32(Console.ReadLine());

        int gcd = EuclideanGCD(A, B);

        Console.WriteLine($"Наибольший общий делитель (НОД) чисел {A} и {B} = {gcd}");
    }

    static int EuclideanGCD(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
