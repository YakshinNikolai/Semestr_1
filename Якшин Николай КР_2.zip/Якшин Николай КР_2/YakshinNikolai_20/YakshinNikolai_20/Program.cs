﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n;

        // Проверка на корректность ввода
        while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
        {
            Console.WriteLine("Пожалуйста, введите неотрицательное целое число.");
        }

        int sum = 0;

        // Вычисление квадрата числа n с помощью суммы нечетных чисел
        for (int i = 0; i < n; i++)
        {
            int term = 2 * i + 1; // текущее нечетное число
            sum += term;          // добавляем к сумме
            Console.WriteLine($"Текущее значение суммы: {sum}");
        }

        Console.WriteLine($"Квадрат числа {n} равен: {sum}");
    }
}
