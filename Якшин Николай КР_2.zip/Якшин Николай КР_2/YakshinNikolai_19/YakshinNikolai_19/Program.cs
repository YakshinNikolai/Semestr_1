﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n;

        // Проверка на корректность ввода
        while (!int.TryParse(Console.ReadLine(), out n) || n < 1)
        {
            Console.WriteLine("Пожалуйста, введите положительное целое число.");
        }

        double result = 0;

        // Вычисление выражения с чередующимися знаками
        for (int i = 1; i <= n; i++)
        {
            double term = 1 + 0.1 * i; // вычисляем текущее слагаемое

            // Чередуем знак: если i четное - вычитаем, если нечетное - прибавляем
            if (i % 2 == 0)
            {
                result -= term;
            }
            else
            {
                result += term;
            }
        }

        Console.WriteLine($"Результат выражения: {result}");
    }
}
