﻿using System;

class Program
{
    static void Main()
    {
        // Начальные значения
        double initialDistance = 10.0; // Пробег в первый день (км)
        double totalDistance = 0.0; // Суммарный пробег (км)
        double dailyDistance = initialDistance; // Пробег за текущий день (км)

        // Запрос процента увеличения
        Console.Write("Введите процент P (0 < P < 50): ");
        double P = Convert.ToDouble(Console.ReadLine());

        // Проверка корректности ввода
        if (P <= 0 || P >= 50)
        {
            Console.WriteLine("Ошибка: процент должен быть в пределах от 0 до 50.");
            return;
        }

        int dayCount = 0; // Счетчик дней

        // Цикл, пока суммарный пробег не превысит 200 км
        while (totalDistance <= 200.0)
        {
            totalDistance += dailyDistance; // Добавляем пробег текущего дня к общему
            dayCount++; // Увеличиваем счетчик дней

            // Увеличиваем пробег на P процентов
            dailyDistance += dailyDistance * (P / 100);
        }

        // Вывод результатов
        Console.WriteLine($"Количество дней K: {dayCount}");
        Console.WriteLine($"Суммарный пробег S: {totalDistance:F2} км");
    }
}
