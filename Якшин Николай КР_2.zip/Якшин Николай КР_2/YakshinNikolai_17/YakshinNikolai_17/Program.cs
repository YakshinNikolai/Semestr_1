﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число Фибоначчи N (> 1): ");
        int N = int.Parse(Console.ReadLine());

        if (N <= 1)
        {
            Console.WriteLine("N должно быть больше 1.");
            return;
        }

        int a = 0; // F(0)
        int b = 1; // F(1)
        int k = 1; // Порядковый номер F(1)

        while (b < N)
        {
            int temp = b;
            b = a + b; // Следующее число Фибоначчи
            a = temp;
            k++;
        }

        if (b == N)
        {
            Console.WriteLine($"Порядковый номер K числа Фибоначчи N = {k}");
        }
        else
        {
            Console.WriteLine("Введенное число не является числом Фибоначчи.");
        }
    }
}
