﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое число n: ");
        int n;

        // Проверка на корректность ввода
        while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
        {
            Console.WriteLine("Пожалуйста, введите неотрицательное целое число.");
        }

        double sum = 0;

        // Суммируем значения от 1.1 до (1 + 0.1 * n)
        for (int i = 1; i <= n; i++)
        {
            sum += 1 + 0.1 * i;
        }

        Console.WriteLine($"Сумма: {sum}");
    }
}
