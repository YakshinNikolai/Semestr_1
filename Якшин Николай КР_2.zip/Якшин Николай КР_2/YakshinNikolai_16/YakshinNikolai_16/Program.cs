﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите положительное число A (длина прямоугольника): ");
        int A = int.Parse(Console.ReadLine());

        Console.Write("Введите положительное число B (ширина прямоугольника): ");
        int B = int.Parse(Console.ReadLine());

        Console.Write("Введите положительное число C (сторона квадрата): ");
        int C = int.Parse(Console.ReadLine());

        if (A <= 0 || B <= 0 || C <= 0)
        {
            Console.WriteLine("Все числа должны быть положительными.");
            return;
        }

        int countA = 0;
        int countB = 0;

        // Подсчет количества квадратов по длине A
        int remainingA = A;
        while (remainingA >= C)
        {
            remainingA -= C;
            countA++;
        }

        // Подсчет количества квадратов по ширине B
        int remainingB = B;
        while (remainingB >= C)
        {
            remainingB -= C;
            countB++;
        }

        // Общее количество квадратов
        int totalSquares = 0;
        for (int i = 0; i < countA; i++)
        {
            totalSquares += countB; // Добавляем количество квадратов по ширине для каждой линии по длине
        }

        Console.WriteLine($"Максимальное количество квадратов со стороной {C}, размещенных на прямоугольнике {A} x {B}: {totalSquares}");
    }
}
