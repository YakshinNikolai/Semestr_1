﻿using System;

class Program
{
    static void Main()
    {
        // Запрос числа N
        Console.Write("Введите целое число N (> 1): ");
        int N = Convert.ToInt32(Console.ReadLine());

        // Проверка условия N > 1
        if (N <= 1)
        {
            Console.WriteLine("Ошибка: N должно быть больше 1.");
            return;
        }

        // Проверка, является ли N числом Фибоначчи
        bool isFibonacci = IsFibonacci(N);

        // Вывод результата
        Console.WriteLine(isFibonacci ? "TRUE" : "FALSE");
    }

    static bool IsFibonacci(int n)
    {
        // Начальные значения чисел Фибоначчи
        int a = 1, b = 1;

        // Проверяем, пока b не станет больше или равным n
        while (b < n)
        {
            int temp = b;
            b = a + b; // Следующее число Фибоначчи
            a = temp; // Предыдущее число Фибоначчи
        }

        // Если b равно n, то n является числом Фибоначчи
        return b == n;
    }
}
