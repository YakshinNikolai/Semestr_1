﻿using System;
namespace stda;
class Program
{
    static void Main()
    {
        Console.WriteLine("«Курский государственный политехнический колледж» \nКонтактная информация \nКонтактные телефоны: +7 (4712) 37-02-19 \nКонтактный факс: +7 (4712) 37-02-19");
    }
}