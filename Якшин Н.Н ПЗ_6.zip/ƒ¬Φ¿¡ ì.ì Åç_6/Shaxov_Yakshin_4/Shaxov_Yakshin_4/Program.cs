﻿using System;
namespace stda;
class Program
{
    static void Main()
    {
        string number1 = Console.ReadLine();
        long number = Convert.ToInt64(number1);
        Console.WriteLine(number.ToString("+# (###) ###-##-##"));
    }
}