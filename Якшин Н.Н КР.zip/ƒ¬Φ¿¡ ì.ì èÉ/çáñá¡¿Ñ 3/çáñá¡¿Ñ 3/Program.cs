﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Задание_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] firstInput = Console.ReadLine().Split();
            List<int> list1 = firstInput.Select(int.Parse).ToList();
            string[] secondInput = Console.ReadLine().Split();
            List<int> list2 = firstInput.Select(int.Parse).ToList();

            HashSet<int> set1 = new HashSet<int>(list1);
            HashSet<int> set2 = new HashSet<int>(list2);

            IEnumerable<int> intersection = set1.Intersect(set2);

            foreach (var number in intersection.OrderBy(n => n))
            {
                Console.WriteLine(number);
            }

        }
    }
}
