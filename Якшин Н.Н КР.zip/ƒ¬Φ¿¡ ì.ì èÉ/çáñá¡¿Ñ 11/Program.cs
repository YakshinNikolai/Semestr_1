﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace _13
{
    internal class Program
    {
        static void Main(string[] args) { 
        string[] text;
            string a = Console.ReadLine();
            string[] kandidats = { };

            while (a != "")
            {
                
                text = a.Split();  
                if (kandidats.Contains(text[0]))
                {
                    int pl = Array.FindIndex(kandidats, row => row == text[0]);
                    kandidats[pl+1] = Convert.ToString(Convert.ToInt32(text[1]) + Convert.ToInt32(kandidats[pl]));
                }
                else
                {
                    kandidats.Append(text[0]);
                    kandidats.Append(text[1]);
                }
                a = Console.ReadLine();
            }
            int[] scores = { };
            int maxscore = 0;
            for (int i = 0; i < kandidats.Length; i++)
            {
                maxscore = Math.Max(maxscore, Convert.ToInt32(kandidats[i]));
                scores.Append(Convert.ToInt32(kandidats[i*2+1]));
            }
            int winner = Array.FindIndex(kandidats, row => row == Convert.ToString(maxscore));
            Console.WriteLine(kandidats);
            Console.WriteLine(winner);
            Console.WriteLine(maxscore);
            Console.WriteLine(kandidats[winner-1] + kandidats[winner]);

            Console.ReadLine();
        }
    }
}
