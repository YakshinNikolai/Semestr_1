﻿using System;
using System.Collections.Generic;
using System.Linq;

public class GuessingGame
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine()); 

        HashSet<int> possibleNumbers = new HashSet<int>(Enumerable.Range(1, n)); 

        while (true)
        {
            string line = Console.ReadLine();

            if (line == "HELP")
            {
                break; 
            }

            string[] numbersStr = line.Split(' '); 
            HashSet<int> askedNumbers = new HashSet<int>(numbersStr.Select(int.Parse)); 
            string answer = Console.ReadLine(); 

            if (answer == "YES")
            {
                possibleNumbers.IntersectWith(askedNumbers);
            }
            else
            {
                possibleNumbers.ExceptWith(askedNumbers);
            }
        }

        Console.WriteLine(string.Join(" ", possibleNumbers.OrderBy(x => x)));
    }
}