﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Задание_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var list1 = Console.ReadLine()?.Split(' ').Select(int.Parse).ToList();
            var list2 = Console.ReadLine()?.Split(' ').Select(int.Parse).ToList();
            HashSet<int> set1 = new HashSet<int>(list1);
            HashSet<int> set2 = new HashSet<int>(list2);
            int count = set1.Intersect(set2).Count();
            Console.WriteLine(count);
        }
    }
}
