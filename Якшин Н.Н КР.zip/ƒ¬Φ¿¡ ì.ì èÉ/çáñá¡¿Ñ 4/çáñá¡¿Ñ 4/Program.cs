﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Задание_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var a = Array.ConvertAll(Console.ReadLine().Split(' '), X => int.Parse(X));
            var hs = new HashSet<int>();
            foreach (var e in a)
                Console.WriteLine(hs.Add(e) ? "NO" : "YES");
        }
    }
}
