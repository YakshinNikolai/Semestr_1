﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Задание_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = "input.txt";
            string text = File.ReadAllText(filePath);

            var words =  new HashSet<string>(text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries));
            Console.WriteLine(words.Count);
        }
    }
}
