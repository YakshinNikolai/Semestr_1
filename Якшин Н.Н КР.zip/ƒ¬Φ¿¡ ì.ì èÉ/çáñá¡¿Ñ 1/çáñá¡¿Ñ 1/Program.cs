﻿using System;
using System.Collections.Generic;


namespace Задание_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var strl = Console.ReadLine();   
            var resultSet = new HashSet<string>(strl.Split());
            Console.WriteLine(resultSet.Count);
            Console.ReadKey();
        }
    }
}
