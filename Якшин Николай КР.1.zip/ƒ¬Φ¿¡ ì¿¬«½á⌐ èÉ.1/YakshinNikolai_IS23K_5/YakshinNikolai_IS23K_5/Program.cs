﻿using System;

public class Solution
{
    public static void Main(string[] args)
    {
        string[] inputLine = Console.ReadLine().Split();
        int n = int.Parse(inputLine[0]);
        double t = double.Parse(inputLine[1]);

        double[] temperatures = new double[n];
        for (int i = 0; i < n; i++)
        {
            temperatures[i] = double.Parse(Console.ReadLine());
        }

        int minIndex = 0;
        for (int i = 1; i < n; i++)
        {
            if (temperatures[i] < temperatures[minIndex])
            {
                minIndex = i;
            }
        }

        int aboveThresholdCount = 0;
        for (int i = 0; i < n; i++)
        {
            if (temperatures[i] > t)
            {
                aboveThresholdCount++;
            }
        }


        Console.WriteLine(minIndex + 1);
        Console.WriteLine(aboveThresholdCount);
    }
}