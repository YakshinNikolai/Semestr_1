﻿using System;

public class Solution
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine(CountValidSequences(n));
    }

    static long CountValidSequences(int n)
    {
        if (n == 1)
        {
            return 3;
        }
        if (n == 2)
        {
            return 8;

        }

        long[,] dp = new long[n + 1, 2];


        dp[1, 0] = 3;
        dp[1, 1] = 1;

        for (int i = 2; i <= n; i++)
        {

            dp[i, 0] = dp[i - 1, 0] + dp[i - 1, 1] + 1;


            dp[i, 1] = dp[i - 1, 0];
        }

        return dp[n, 0] + dp[n, 1];
    }
}
