﻿using System;

public class Solution
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split();
        int n = int.Parse(input[0]);

        int count = 0;
        for (int i = 1; i <= n; i++)
        {
            int number = int.Parse(input[i]);


            if ((number & 7) == 0)
            {
                count++;
            }
        }

        Console.WriteLine(count);
    }
}