﻿using System;

public class Solution
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split();
        int a = int.Parse(input[0]);
        int b = int.Parse(input[1]);

        int count = 0;
        for (int i = a; i <= b; i++)
        {
            string octal = ConvertToOctal(i);
            string newOctal = ModifyOctal(octal);
            int newDecimal = ConvertFromOctal(newOctal);

            if (i > newDecimal)
            {
                count++;
            }
        }

        Console.WriteLine(count);
    }


    static string ConvertToOctal(int decimalNumber)
    {
        if (decimalNumber == 0) return "0";
        string octal = "";
        while (decimalNumber > 0)
        {
            octal = (decimalNumber % 8) + octal;
            decimalNumber /= 8;
        }
        return octal;
    }

    static string ModifyOctal(string octal)
    {
        if (octal.Length < 2) return octal;

        int lastDigit = int.Parse(octal[octal.Length - 1].ToString());
        int penultimateDigit = int.Parse(octal[octal.Length - 2].ToString());

        int newPenultimateDigit;
        if (penultimateDigit == 7)
        {
            newPenultimateDigit = 0;
            if (lastDigit % 2 == 0)
            {
                lastDigit++;
            }
            else
            {
                lastDigit--;
            }
        }
        else
        {
            newPenultimateDigit = penultimateDigit + 1;
        }

        return octal.Substring(0, octal.Length - 2) + newPenultimateDigit + lastDigit;
    }

    static int ConvertFromOctal(string octal)
    {
        int decimalNumber = 0;
        int power = 1;
        for (int i = octal.Length - 1; i >= 0; i--)
        {
            int digit = int.Parse(octal[i].ToString());
            decimalNumber += digit * power;
            power *= 8;
        }
        return decimalNumber;
    }
}