﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Solution
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        string[] words = new string[n];

        for (int i = 0; i < n; i++)
        {
            words[i] = Console.ReadLine();
        }


        var groupedWords = words.GroupBy(word => word.Last());
        var longestMessage = groupedWords.OrderByDescending(group => group.Count()).First();

        Console.WriteLine(longestMessage.Count());
    }
}