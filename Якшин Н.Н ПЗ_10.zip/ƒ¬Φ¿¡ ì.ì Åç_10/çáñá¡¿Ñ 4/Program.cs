﻿using static System.Console;
using static System.Math;

class Program
{
    static void Main(string[] args)
    {
        Write("Введите координаты x и y (от 1 до 8): ");
        string input = ReadLine();
        string[] coordinates = input.Split(' ');

        
        int x = Convert.ToInt32(coordinates[0]);
        int y = Convert.ToInt32(coordinates[1]);

        
        if (x < 1 || x > 8 || y < 1 || y > 8)
        {
            WriteLine("Координаты должны быть в диапазоне от 1 до 8.");
            return;
        }

        
        bool isWhite = (x + y) % 2 != 0;

        
        WriteLine($"Квадрат ({x}, {y}) {(isWhite ? "белый" : "черный")}");

       
        ReadKey();
    }
}
