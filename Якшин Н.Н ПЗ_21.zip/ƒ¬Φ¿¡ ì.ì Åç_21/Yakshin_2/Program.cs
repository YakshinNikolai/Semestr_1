﻿using System;
class Program
{
    static void Main(string[] args)
    {
        AverageMethods avgMethods = new AverageMethods();

        Console.WriteLine("Выберите тип массива (1 - int, 2 - float): ");
        int choice = int.Parse(Console.ReadLine());

        if (choice == 1)
        {
            Console.WriteLine("Введите целые числа через пробел: ");
            string input = Console.ReadLine();
            string[] stringNumbers = input.Split(' ');
            int[] intArray = Array.ConvertAll(stringNumbers, int.Parse);
            double intAverage = avgMethods.Average(intArray);
            Console.WriteLine($"Среднее арифметическое для int массива: {intAverage}");
        }
        else if (choice == 2)
        {
            Console.WriteLine("Введите числа с плавающей запятой через пробел: ");
            string input = Console.ReadLine();
            string[] stringNumbers = input.Split(' ');
            float[] floatArray = Array.ConvertAll(stringNumbers, float.Parse);
            double floatAverage = avgMethods.Average(floatArray);
            Console.WriteLine($"Среднее арифметическое для float массива: {floatAverage}");
        }
    }
}
public class AverageMethods
{
    public double Average(int[] numbers)
    {
        double sum = 0;
        foreach (int number in numbers)
        {
            sum += number;
        }
        return sum / numbers.Length;
    }
    public double Average(float[] numbers)
    {
        double sum = 0;
        foreach (float number in numbers)
        {
            sum += number;
        }
        return sum / numbers.Length;
    }
}